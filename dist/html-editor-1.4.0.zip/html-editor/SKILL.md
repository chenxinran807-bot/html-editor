---
name: html-editor
description: 给任意 HTML 页面或 Streamlit 应用注入可视化标注层，让用户在 AI 生成的预览里"指哪打哪"地反馈——直接在页面上点选元素、写批注，再导出成结构化文本粘回对话，AI 据此精确修改对应元素。**凡是涉及生成 HTML、网页、网页原型、产品原型、demo、页面、落地页、报告页的任务，都应默认启用本技能，在产出 HTML 时注入标注层，方便用户直接在页面上圈点反馈迭代。** 也适用于对已有的任意静态 HTML 或 Streamlit 应用收集可视化修改意见。触发词：生成 html、生成网页、网页原型、html 原型、产品原型、原型、prototype、做个页面、做个 demo、demo、设计页面、设计、落地页、Streamlit、启用 HTML Editor、标注、框选标注、点选批注、可视化反馈、在页面上标记、annotate html、给 HTML 加批注。
---

# HTML Editor

给**任意 HTML** 加上一层可视化标注能力，形成 **"生成 → 注入 → 标记修改 → 交给 Agent → 回改"** 的迭代闭环。界面采用 macOS 原生 Inspector 风格，但始终是覆盖在原 HTML 上的轻量面板，不会变成独立设计工具。

解决的具体问题：用户对着 AI 生成的页面反馈时，用文字描述"第三个卡片的标题字太大"既慢又容易指错。有了标注层，用户直接在页面上点元素、写批注，导出成 AI 可解析的结构化文本，AI 就能定位到精确的元素去改。

## 何时使用

- 用户在迭代 AI 生成的 HTML（原型、Demo、报告、落地页等），希望**在页面上直接点选元素写意见**而不是打字描述位置。
- 用户说"想要能标注的 HTML""让我在页面上圈一下""可视化反馈""点选批注"等。
- 拿到任意静态 HTML，需要收集多人的可视化修改意见。
- 用户要标注 Streamlit 应用，或明确说“启用 HTML Editor”。

## 核心设计（为什么这样做）

- **注入而非改写**：脚本只把标注层 `<script data-annotator="true">` 贴到 `</body>` 前。控件操作会临时预览，取消或保存后恢复业务页面原状；真正修改仍由 Agent 根据标注执行。
- **零污染零冲突**：交互代码整体用 IIFE 包裹，不写全局变量；所有类名 `annotator-` 前缀、id `ann-` 前缀，不会撞用户样式。
- **捕获阶段拦截**：标注模式下 `mouseover/click` 以捕获阶段绑定并 `preventDefault + stopPropagation`，即便原页面有点击逻辑也会被优先拦截，点了不误触发。
- **点选 + 拖拽框选**：基于 Pointer 事件统一鼠标/触摸/手写笔，位移超阈值判为「拖拽框选」，收集区域内 60% 以上落框的最外层元素并算出公共容器，作为「区域标注」；否则判为「点选」单元素。
- **稳定唯一选择器**：优先 `#id`，否则逐层向上拼路径、同标签兄弟补 `:nth-of-type(n)`，产出如 `body > div > section:nth-of-type(2) > h3` 的唯一可定位选择器（自动过滤标注层自己的 `ann-` id）。这是 AI 能精确回改的技术核心。
- **结构化导出**：导出固定模板，末尾自带"逐一修改并输出完整 HTML"的指令——就是给 AI 看的协议格式。
- **沙箱兼容复制**：预览常跑在 iframe 沙箱，`navigator.clipboard` 可能被禁，复制做了 Clipboard API → 隐藏 textarea + `execCommand` 的双重 fallback。
- **本地持久化**：标注写入 `localStorage`（按页面路径隔离 key），刷新/切页自动恢复；恢复时按选择器重新绑定元素，绑不上的会标记「元素已变化」但保留批注文本。
- **多页 pin 跟随**：对多页 HTML（`.page` / `.active` 约定）用 MutationObserver 监听切页，自动隐藏/显示对应页的标注 pin。

## 使用流程

### 1. 注入标注层

对已有的 HTML 文件执行：

```bash
python3 scripts/wrap_annotator.py <input.html> -o <output.html>
```

由 `prd-demo` 生成的页面必须同时绑定生成上下文：

```bash
python3 scripts/wrap_annotator.py <input.html> -o <output.html> \
  --task-id <taskId> \
  --session-id <sessionId> \
  --prd-fingerprint <sha256:...>
```

三个参数必须同时提供。包装器只写入不可见的 workflow meta 和标注脚本，不修改业务 DOM。

- 不带 `-o` 时默认输出到 `<input>.annotated.html`（不覆盖原文件）。
- 幂等：对已注入过的 HTML 不会重复注入。
- **升级老页面**：如果 HTML 里已注入过旧版本标注层，用 `--force`（或 `--replace`）会先剥离旧的 `<script/style data-annotator>` 再注入最新版：
  ```bash
  python3 scripts/wrap_annotator.py <old.html> -o <old.html> --force
  ```
- 若这个 HTML 是本 skill 或其它流程刚生成的，注入后再交付/预览给用户。

### 2. 用户在页面上标注

打开注入后的 HTML，页面底部出现三个操作：**标记修改 / 我的修改 / 完成标注**。

- 点「标记修改」后，hover 元素蓝框高亮；点击内容后打开 macOS Inspector 风格的修改面板。
- **两种标注方式**：①**点选**单个元素；②**拖拽框选**一片区域（橡皮筋框），自动识别区域内元素与公共容器，作为一条「区域标注」。
- **移动端支持**：基于 Pointer 事件，手机/平板可点选与拖拽框选（标注模式下页面暂停滚动，退出即恢复）。
- 选中页面内容后，面板只展示与它相关的设置：文字可改内容、字号、字重、行距、对齐和颜色；按钮或卡片可改间距、背景、边框、圆角和阴影；图片可选择替换参考、裁切方式和圆角。
- 颜色可从**当前页面常用颜色 / 屏幕吸色 / 系统取色器**选择。屏幕吸色仅在浏览器支持时出现，其余入口始终可用。
- 间距不要求用户理解像素、margin 或 padding：直接拖动选中元素四边，通过页面实时效果调整；面板只使用“**和旁边元素的距离 / 内部留白**”。
- 技术数值、选择器和色值默认收在“高级信息”；自然语言输入仍用于补充控件无法表达的要求或添加参考图。
- **回车保存 · Shift+回车换行 · Esc 取消**；保存后元素/区域上出现数字 pin（区域另有虚线轮廓）。
- 「我的修改」可查看、编辑、删除单条，或清空全部；不会向用户展示 CSS 选择器、HTML 片段和图片编码等技术字段。
- 「完成标注」会整理并复制修改要求，明确提示用户回到 Agent 对话粘贴发送；剪贴板受限时才展开手动复制区。
- **参考图随导出一起带走（免二次上传）**：文本剪贴板带不了图片文件，所以导出时会把标注里附的参考图**压缩后以 base64 内嵌进导出文本末尾**（包在 `=====参考图内嵌数据=====` … `=====参考图数据结束=====` 之间，每张用 `[[[IMG:标注1-参考图1.png]]] … [[[/IMG]]]` 包裹）。用户**只需整段复制粘贴一次**，AI 端即可自动解析出图片，无需再单独在聊天框上传。同时仍会把原图**下载为文件**（缩略图 + 「重新下载参考图」按钮）作为「粘贴被截断」时的兜底。参考图 dataURL 也尽量写入 localStorage（超配额自动降级只存文件名）。
  - **AI 端解析约定**：收到粘贴文本后，从 `[[[IMG:文件名]]]` 与 `[[[/IMG]]]` 之间取出 `data:image/...;base64,...`，解码写成对应文件名的图片再读取，即为该标注的参考图。
- **标注自动持久化**：数据存 `localStorage`（按页面路径隔离），刷新页面/切页不丢；元素若被改动会在列表标记「元素已变化」。
- 快捷键：标注模式下按 `Esc` 可直接退出；批注输入框点击外部空白处自动关闭。

用户完整操作路径：

```text
标记修改 → 点击或框选页面内容 → 说出要求 → 保存修改
→ 在“我的修改”中复核 → 完成标注 → 复制修改要求 → 粘贴给 Agent
```

### 3. 用户把修改要求粘回对话

完成标注时一次复制两部分：普通用户可读的修改摘要，以及 fenced `prd-demo-annotations` JSON。结构化部分包含 `taskId`、`sessionId`、prdFingerprint 和每条标注的 `targetClauseId`、targetNodeSelector、intent、`scope: target-only`、`changes[]`。

- `changes[]` 保存控件产生的确定值：`category / property / before / after / unit / direction`。消费 Agent 应优先执行这些确定值，再用 `intent` 补充控件无法表达的要求。
- 旧 HTML 导出的标注没有 `changes` 时按空数组处理，继续只消费 `intent`，不得因此拒绝旧标注。

- 业务节点带 `data-prd-clause` 时优先用 `targetClauseId` 稳定定位。
- 旧 HTML 没有 clause 时保留 selector，并把 `targetClauseId` 设为 `null`，不得编造。
- 消费 Agent 必须核对 taskId/sessionId 后再修改，并证明未受影响页面保持不变。

导出格式固定如下：

```
页面: 推荐产品数据周报 (https://xxx.aime-app.../index.html)

[标注 1] 元素: <h3> "季度销售概览"
  页面区块: page-2
  选择器: body > div > section:nth-of-type(2) > h3
  片段: <h3 class="title">季度销售概览</h3>
  批注: 标题字号太大，改小一号；颜色换成主题蓝

[标注 2] 元素: <button> "提交"
  选择器: #submit-btn
  片段: <button id="submit-btn" class="btn">提交</button>
  批注: 按钮挪到右下角

[标注 3] 区域框选（含 2 个元素）
  容器选择器: body > div > section:nth-of-type(2)
  区域内元素:
    - <div> "冷启动优化…"  选择器: body > div > section:nth-of-type(2) > div > div:nth-of-type(1)
    - <div> "负反馈体系…"  选择器: body > div > section:nth-of-type(2) > div > div:nth-of-type(2)
  批注: 这块整体改成两列布局

---
请根据以上标注逐一修改对应元素（元素类用「选择器」定位、「片段」辅助确认；区域类需综合调整「区域内元素」整体），并输出修改后的完整 HTML。
```

### 4. AI 按标注精确回改

解析每条标注：用 `选择器` 在原 HTML 里定位元素，按 `批注` 落实修改，逐条完成后输出**修改后的完整 HTML**。改完可再次注入标注层交付，进入下一轮闭环。

## Streamlit 自动工作流（增量能力）

Streamlit 使用运行时浏览器注入，不得修改用户源文件、页面组件或依赖声明；静态 HTML 主要流程保持不变，继续使用上面的包装器。每次执行浏览器操作前，以当前安装的 Browser control skill 作为 source of truth：按其方式定位插件根目录、初始化并选择浏览器、完整读取所选浏览器文档，再操作标签页。不要在本技能中硬编码插件版本路径。

注入前从本技能目录读取 `assets/streamlit-annotator.js`。将配置写入 `window.__HTML_EDITOR_STREAMLIT_CONFIG__`，再把运行时代码注入活动的 Streamlit 标签页。注入前先检查 `window.__HTML_EDITOR_STREAMLIT__`；若 marker 已存在，不要再次注入。注入成功后按当前 Browser 文档支持的方式使浏览器和目标标签页可见、置于用户可操作状态。

项目输入可以是项目目录或 `.zip`，Agent 对两者使用完全相同的 `inspect`、`launch` 命令，不在命令外手动解包。ZIP 会经过路径、文件类型、条目数、单文件大小、总展开大小和压缩比安全检查，再安全提取到私有临时目录；源归档保持不变。`inspect` 结束即清理临时目录，`launch` 在进程退出或发生错误时清理。遇到不安全或过大的归档时，原样报告 adapter 的明确错误，不得手动解压来绕过安全检查。

`inspect` 和 launch metadata 都包含 `pythonExecutable`、`pythonSource`、`runtimeDigest`、`runtimeScope`。项目虚拟环境由 adapter 自动优先选择（`pythonSource: project-venv`），直接使用选定的 Python 可执行文件，不运行激活脚本，也不通过 shell 启动。找不到项目虚拟环境时回退到 `pythonSource: current-interpreter`、`runtimeScope: interpreter-only`；这个 interpreter-only scope 只覆盖解释器本体，运行时保证较低，应明确告知用户。缺少依赖时仍遵循下面的批准流程，不自动安装或改写依赖声明。

### 路径 1：现有本地应用

1. 使用当前 Browser skill 的标签页发现与检查流程，确认目标标签页是 Streamlit。若有多个候选且匹配不明确，列出候选并请用户选定，禁止猜测。
2. 项目已知时，运行 `python3 scripts/streamlit_adapter.py inspect <project>`，读取项目名、入口与项目指纹；紧接注入前必须重新运行同一 inspect，并只使用这次 fresh inspect 的 `projectFingerprint`。出现项目指纹不匹配时停止并让用户确认目标。
3. 用项目名与 `projectFingerprint` 配置 `__HTML_EDITOR_STREAMLIT_CONFIG__`，读取 adapter asset，注入 runtime，然后显示目标标签页。
4. 如果只有正在运行的标签页、没有项目文件可供计算 fingerprint，明确使用 session-only identity（`session fingerprint`），不得编造项目身份：为每次会话生成新的加密安全随机值，格式必须为 `sha256:<64hex>`，并生成唯一的 session projectName；两者不得复用。此模式的源位置保证较低，只能在本次会话中辅助定位。因为 runtime 存储键包含 projectName/fingerprint，新会话不能恢复旧标注；残留 localStorage 对新身份不可访问。会话结束时可调用 adapter 的 `destroy()` 清理页面 overlay；它不会删除 localStorage，只有用户明确要求且当前 Browser workflow 允许时才清理已知旧存储键。

### 路径 2：上传的完整项目或传入项目

1. 对上传或传入的项目目录或 `.zip` 运行 `python3 scripts/streamlit_adapter.py inspect <project>`。检查 JSON 中的入口、候选入口、依赖声明、项目指纹和运行时身份；候选入口匹配不明确时请用户选择。
2. 对目录或 `.zip` 都原样运行 `python3 scripts/streamlit_adapter.py launch <project> [--entry <file>] [--port <port>]`。解析首行 launch metadata 的 `url`、`projectFingerprint`、`pythonExecutable`、`pythonSource`、`runtimeDigest`、`runtimeScope`，并保留该命令所在进程；这行 metadata 只说明启动命令已发出，不代表服务可用。
3. 对 metadata URL 执行 HTTP probe，要求成功响应，再按当前 Browser skill 工作流打开页面并确认存在 Streamlit root。只有 HTTP probe 和页面检查都成功后才能确认服务 ready；然后对同一个目录或 ZIP 重新运行 `python3 scripts/streamlit_adapter.py inspect <project>`。将 fresh inspect 的 `projectFingerprint`、`runtimeDigest`、`runtimeScope` 与 launch metadata 对应值逐一比较；三者全部一致才允许注入，任一不一致都说明项目内容或 runtime 已改变，必须停止。
4. 使用这个经过比较的可信 fresh inspect 指纹配置项目，读取 `assets/streamlit-annotator.js`，检查 marker 后仅注入一次；显示标签页并保持进程运行，直到用户结束预览。

### 失败处理

- **缺少依赖**：报告缺少项和现有依赖文件；安装依赖属于外部变更，需要用户批准，且在批准前后都让项目的依赖声明保持不变，除非用户另行明确要求修改。
- **启动错误**：保留退出码与精简错误输出，停止打开或注入，不把失败进程说成已就绪。即使 launch metadata 已经打印，metadata 之后发生启动失败也必须报告为失败。
- **浏览器注入错误**：停止并报告注入阶段与浏览器错误；不得改写用户源码作为替代。
- **匹配不明确**：无论是入口还是浏览器标签页，都让用户选择，不自动挑选。
- **项目或运行时身份不匹配**：`projectFingerprint`、`runtimeDigest`、`runtimeScope` 任一不匹配都停止注入或消费标注，重新 inspect/核对项目；未经用户确认不得跨项目或 runtime 复用配置或标注。

## 文件说明

- `scripts/wrap_annotator.py` — 注入包装脚本（把标注层贴进任意 HTML，支持 `--force` 更新老页面）。
- `scripts/streamlit_adapter.py` — 只读检查并启动 Streamlit 项目，输出项目指纹与 launch metadata；是否可用仍由 HTTP probe 验证。
- `assets/annotator-inject.js` — 标注交互层本体（纯前端 JS，自包含无依赖）。
- `assets/streamlit-annotator.js` — 注入活动 Streamlit 标签页的运行时 adapter asset。

静态 HTML 的两个原有文件完全自包含，不需要任何额外依赖；Streamlit 增量流程使用项目自身已声明的 Python 环境。

## 后续可选增强（不作为运行前提）

- 可选接入成熟图标库、UI 组件案例、字体和排版预设，给用户提供更直接的样式参考。
- 可选增加参考图库或设计案例入口，让用户一键引用某种视觉方向。
- 所有外部资源都必须是增强项：网络不可用或资源加载失败时，自动回退到内联 SVG 和系统字体，标注、保存和交付 Agent 的主流程仍可完整运行。
